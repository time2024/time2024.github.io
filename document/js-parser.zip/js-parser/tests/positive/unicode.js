// Unicode identifiers
var α = 42;
var 变量 = "中文";
var ヴァリアブル = 123;
var $dollar = 1;
var _underscore = 2;

// Unicode in strings
var greeting = "Hello, 世界!";