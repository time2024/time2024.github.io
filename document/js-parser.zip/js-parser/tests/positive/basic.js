// Basic JavaScript syntax
var x = 42;
let y = "hello";
const z = true;

function add(a, b) {
    return a + b;
}

if (x > 10) {
    console.log("x is large");
} else {
    console.log("x is small");
}

while (y < 100) {
    y = y + 1;
}