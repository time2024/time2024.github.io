// Invalid JavaScript syntax
var = 123;  // Missing identifier

function {  // Missing function name
    return 42;
}

if x > 10 {  // Missing parentheses
    console.log("error");
}